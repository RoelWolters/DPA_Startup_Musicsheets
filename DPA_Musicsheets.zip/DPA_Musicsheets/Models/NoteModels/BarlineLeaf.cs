﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPA_Musicsheets.Models.NoteModels
{
	class BarlineLeaf : SongLeaf
	{
		// A barline can't have variable properties, but it can't be described as a note and making it a base SongLeaf would be incorrect.
	}
}
